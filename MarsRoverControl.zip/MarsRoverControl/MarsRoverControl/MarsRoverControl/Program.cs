﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MarsRoverControl;

namespace MarsRoverControl
{
    class Program
    {
        static void Main(string[] args)
        {
            MarsRover rover = new MarsRover();

            while (true)
            {
                Console.WriteLine(" Enter up to 5 commands for the rover (e.g '50m', 'Left', '23m', 'Right', '4m')");
                string input = Console.ReadLine();

                string[] commands = input.Split(',');

                foreach (string command in commands)
                {
                    if (!rover.ExecuteCommand(command.Trim()))
                    {
                        Console.WriteLine("Rover cannot execute further commands. It has reached the perimeter of the expolaration area.");
                        break;
                    }
                }
                Console.WriteLine(" Current Position : " + rover.CurrentPosition() + "facing " + rover.CurrentDirection());

                // Console.WriteLine($" Current Position : {rover.CurrentPosition()}, facing {rover.CurrentDirection()} ");
            }

        }

    }

    class MarsRover
    {
        private int x_axis = 0;
        private int y_axis = 0;
        private string direction = "South"; // setting up current direction south as mentioned in problem statement

        public bool ExecuteCommand(string command) // passing user input as a command in string format
        {
            switch (command) // checking on user input and it will perform action accordingly 
            {
                case "Left": // if this case matches with user input then it will execute code within TurnLeft method
                    TurnLeft();
                    break;
                case "Right":  // if this case matches with user input then it will execute code within TurnRight method
                    TurnRight();
                    break;
                default: // if non of the input matches or input ends with letter m. then it will execute the defaut statement
                    if (command.EndsWith("m") && int.TryParse(command.Substring(0, command.Length - 1), out int distance))
                    {
                        MoveForward(distance);
                    }
                    else // if none of the input matches then else block will execute written as invalid statement
                    {
                        Console.WriteLine("Invalid command (Please enter valid command from above)");
                        return false;
                    }
                    break;
            }
            return true;

        }

        private void TurnLeft()
        {
            switch (direction)
            {
                case "North":
                    direction = "West";
                    break;
                case "East":
                    direction = "North";
                    break;
                case "South":
                    direction = "East";
                    break;
                case "West":
                    direction = "South";
                    break;
            }
        }

        private void TurnRight()
        {
            switch (direction)
            {
                case "North":
                    direction = "East";
                    break;
                case "East":
                    direction = "South";
                    break;
                case "South":
                    direction = "West";
                    break;
                case "West":
                    direction = "North";
                    break;
            }
        }

        private void MoveForward(int distance) // This will execute when user give a command to rover to move forward (e.g 50m, 20m, 4m)
        {
            switch (direction)
            {
                case "North":
                    y_axis += distance;
                    break;
                case "East":
                    x_axis += distance;
                    break;
                case "South":
                    y_axis -= distance;
                    break;
                case "West":
                    x_axis -= distance;
                    break;
            }



            if (x_axis < 1 || x_axis > 100 || y_axis < 1 || y_axis > 100)
            {
                /*this block will check distance covered by rover with X and Y axis of 100x100 squared area, if it's crossing 100m then 
                the below statement will be displayed*/

                Console.WriteLine("Rover has reached the perimeter of the exploration area");
            }
        }


        public String CurrentDirection()
        {
            // This methos will return the current direction of rover
            return direction;
        }

        public string CurrentPosition()
        {
            // This method will written current position of rover with X and Y axis.
            return $" {x_axis},{y_axis} ";
        }


    }
}
